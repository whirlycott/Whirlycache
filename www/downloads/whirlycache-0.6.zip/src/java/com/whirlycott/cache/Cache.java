/*
Copyright 2004 		Philip Jacob <phil@whirlycott.com>
				  	Seth Fitzsimmons <seth@note.amherst.edu>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/


package com.whirlycott.cache;


/**
 * Defines a simple interface that all caches should implement.
 * @author  phil
 */
public interface Cache {
	
	/**
	 * Retrieve an object from the cache.
	 * @param key key associated with desired object.
	 * @return object identified by provided key.
	 */
	public Object retrieve(Object key);
	
	/**
	 * Store an object in the cache.
	 * @param key key associated with object to store.
	 * @param value object identified by provided key.
	 */
	public void store(Object key, Object value);
	
	/**
	 * Remove an object from the cache.
	 * @param key key associated with object to remove.
	 * @return object that was removed.
	 */
	public Object remove(Object key);
    
	/**
	 * Clear the cache.
	 */
    public void clear();
    
    /**
     * Get the current size of the cache.
     */
    public int size();
        
}
