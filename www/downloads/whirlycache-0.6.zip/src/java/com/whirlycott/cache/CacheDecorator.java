/*
 Copyright 2004 		Philip Jacob <phil@whirlycott.com>
 Seth Fitzsimmons <seth@note.amherst.edu>
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

package com.whirlycott.cache;

import java.util.Arrays;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Owns the cache tuning thread and provides housekeeping facilities for 
 * ManagedCache implementations.  One CacheDecorator is created for each Cache
 * named in the whirlycache.xml configuration file.
 *   
 * @author Phil Jacob
 */
public class CacheDecorator implements Runnable, Cache {
	
	/** We keep all of the stats in the recordkeeper. */
	protected RecordKeeper recordKeeper = new RecordKeeper();
	
	/** There's a default sleep time of 10 seconds. */
	protected long sleepTime = 10000L;
	
	/** This is the cache we're managing. */
	protected volatile ManagedCache managedCache;
	
	/** This is the memory size for the adaptive caching in implementations that support it. */
	//TODO - make this a percentage of the max size or something...?
	protected int adaptiveMemorySize = 5000;
	
	/** Overflow buffer for the adaptive array. */
	protected final int adaptiveMemorySizeOverflow = 512;
	
	/** The array that holds the adaptive results. */
	protected volatile int adaptiveResults[];
	
	/** The counter for our current position in the adaptive result array. */
	protected volatile int adaptiveResultCounter = 0;
	
	/** Logger */
	private final static Log log = LogFactory.getLog(CacheDecorator.class);
	
	/** The soft limit of the max number of items that can be put in the cache. */
	protected int maxSize;
	
	/** The policy used during maintenance. */
	protected CacheMaintenancePolicy policy = null;
	
	/** Configuration */
	protected Map configuration = null;
	
	/** Shutdown flag */
	protected boolean shutdown = false;
	
	public CacheDecorator(final ManagedCache _managedCache, final Map _configuration) {
		configuration = _configuration;
		
		//Adaptive size plus the buffer (to prevent ArrayIndexOutOfBoundsExceptions)s
		adaptiveResults = new int[adaptiveMemorySize + adaptiveMemorySizeOverflow]; 
		
		//This is the cache which we are managing.
		managedCache = _managedCache;
		
		//Do some configuration.
		configure();
		
		//Start up the management thread.
		final Thread t = new Thread(this);
		t.setName("Whirlycache Tuner (" + configuration.get(Constants.CONFIG_NAME) + ")");
		t.setDaemon(true);
		t.start();
	}
	
	/**
	 * Configures the Cache being decorated.
	 */
	protected void configure() {
		//Set up the max size.
		setMaxSize(new Integer((String)configuration.get("maxsize")).intValue());
		
		//Sleeptime.
		setSleepTime(new Long((String)configuration.get("tuner-sleeptime")).longValue() * 1000L);
		
		//Policy class config.
		final String policyClass = (String)configuration.get("policy");
		CacheMaintenancePolicy policy = null;
		try {
			policy = (CacheMaintenancePolicy) Class.forName(policyClass).newInstance();
		} catch (Exception e) {
			log.fatal("Cannot make an instance of policy class " + policyClass, e);
		}
		setPolicy(policy);
		if (policy != null) {
			policy.setCache(managedCache);
			policy.setConfiguration(configuration);
		}
	}
	
	
	/**
	 * Starts up the background maintenance thread.
	 */
	public void run() {
		log.debug("Tuning thread started...");
		
		while ( !shutdown ) {
			final long startTotalQuestions = recordKeeper.getTotalOperations();;
			final long startTime = System.currentTimeMillis();
			
			//Adapt to mostly read or mostly write.
			tuneCache();
			
			//Perform tuning and maintenance.
			policy.performMaintenance();
			
			try {
				//Sleep for a bit
				Thread.sleep(sleepTime);             
			} catch (InterruptedException e) {
				log.error(e.getMessage(), e);
				e.printStackTrace();
			}
			
			final long endTotalQuestions = recordKeeper.getTotalOperations();
			final long endTime = System.currentTimeMillis();
			
			if (sleepTime > 0L) 
				log.debug("Query rate: " + (endTotalQuestions - startTotalQuestions) / (sleepTime / 1000L) + " per sec");
			
			log.info( getEfficiencyReport() );
			log.debug("Cache tuning complete");
		}
		
		log.debug("Shutting down...");
	}
	
	/**
	 * Tunes the managed cache for a mostly read or write environment.
	 */
	protected void tuneCache() {
		final float adaptiveRatio = getAdaptiveRatio();
		if (adaptiveRatio > 0.5F) {
			log.debug("Read optimizations are ON: " + adaptiveRatio);
			managedCache.setMostlyRead(true);
		} else {
			log.debug("Read optimizations are OFF: " + adaptiveRatio);
			managedCache.setMostlyRead(false);
		}
	}
	
	/**
	 * Specify the ManagedCache that this Decorator owns.
	 * @param cache The ManagedCache to set.
	 */
	protected void setManagedCache(final ManagedCache cache) {
		this.managedCache = cache;
		log.debug("Managing a Cache with type: " + cache.getClass() );
	}
	
	/**
	 * Returns the total hitrate since this Cache was started.
	 * @return Total hitrate.
	 */
	protected float getTotalHitrate() {
		return new Long(recordKeeper.getHits()).floatValue() / new Long(recordKeeper.getTotalOperations()).floatValue();
	}
	
	/**
	 * Looks at the last 'n' queries to determine whether the Cache should turn
	 * on optimizations for a mostly-read environment (if the underlying
	 * implementation of ManagedCache supports this).
	 * @param _value varies depending on whether this was a read, write, or
	 * removal.
	 */
	protected void doAdaptiveAccounting(final int _value) {
		//We only care about the last 'n' adaptiveResults.
		final int currentCounter = adaptiveResultCounter;
		if ( currentCounter >= adaptiveMemorySize ) {
			adaptiveResultCounter = 0;
			adaptiveResults[0] = _value;
		} else {
			adaptiveResults[currentCounter] = _value;
			adaptiveResultCounter++;
		}
	}
	
	/**
	 * Gets an Object from the Cache.
	 */
	public Object retrieve(final Object _key) {
		//Record a read.
		doAdaptiveAccounting(1);
		
		//Increment the number of totalQuestions.
		recordKeeper.incrementTotalOperations();
		
		//Set up the return value
		final Item cachedItem = (Item) managedCache.get(_key);
		if (cachedItem != null) {
			
			//Bump the numbers.
			cachedItem.setUsed( recordKeeper.getTotalOperations() );
			cachedItem.incrementCount();
			
			//Increment the adaptive algorithm and the hitcounter.
			final Object retval = cachedItem.getItem();
			if ( retval != null )
				recordKeeper.incrementHits();

			return retval;
		} else {
			
			//Found nothing inside the cache.
			return null;
		}
	}
	

	/**
	 * Store an object in the cache.
	 */
	public void store(final Object _key, final Object _value) {
		recordKeeper.incrementTotalOperations();
		
		if ( _key != null && _value != null ) {
			final Item cachedValue = new Item(_value, recordKeeper.getTotalOperations());
			managedCache.put(_key, cachedValue);
			doAdaptiveAccounting(0);
		}
		
	}
	
	/**
	 * Removes an Object from the Cache and returns the removed Object.
	 * @param _key key associated with object to remove.
	 */
	public Object remove(final Object _key) {
		recordKeeper.incrementTotalOperations();
		if ( _key != null ) {
			final Object retval = managedCache.remove(_key);
			doAdaptiveAccounting(0);
			return retval;
		} else {
			return null;
		}
	}
	
	/**
	 * Returns the number of items in the Cache.
	 * @return number of items in the cache.
	 */
	public int size() {
		recordKeeper.incrementTotalOperations();
		return managedCache.size();
	}
	
	/**
	 * Clears the cache.
	 */
	public void clear() {
		log.info("Clearing cache");
		managedCache.clear();
		Arrays.fill( adaptiveResults, 0 );
	}
	
	/** 
	 * Returns an efficiency report string for this cache.
	 * @return efficiency report for this cache. 
	 */
	public String getEfficiencyReport() {
		final StringBuffer buffer = new StringBuffer();
		buffer.append("Size: ");
		buffer.append( size() );
		buffer.append("; Questions: ");
		buffer.append(recordKeeper.getTotalOperations());
		buffer.append("; Hits: ");
		buffer.append(recordKeeper.getHits());
		buffer.append("; Adaptive r/w ratio: ");
		buffer.append(getAdaptiveRatio());
		buffer.append("; Total hitrate: ");
		buffer.append(getTotalHitrate());
		return buffer.toString();
	}
	
	/**
	 * Calculates the adaptive hit rate for this cache.
	 * @return adaptive hit ratio.
	 */
	public float getAdaptiveRatio() {
		final int copy[] = new int[adaptiveMemorySize];
		System.arraycopy(adaptiveResults, 0, copy, 0, adaptiveMemorySize);
		int positives = 0;
		for ( int i=0; i < copy.length; i++ ){
			if ( copy[i] == 1 )
				positives++;
		}
		//log.info("Positives: " + positives + "; Total: " + adaptiveMemorySize);
		return new Float(positives).floatValue() / new Float(adaptiveMemorySize).floatValue();
	}
	
	/**
	 * Tells the underlying ManagedCache implementation to turn on
	 * optimizations for a mostly-read environment (if supported).
	 * @param _mostlyRead whether most operations are expected to be reads.
	 */
	public void setMostlyRead(final boolean _mostlyRead) {
		recordKeeper.incrementTotalOperations();
		managedCache.setMostlyRead(_mostlyRead);
	}
	
	/**
	 * @return Returns the adaptiveMemorySize.
	 */
	protected int getAdaptiveMemorySize() {
		return adaptiveMemorySize;
	}
	
	/**
	 * @param adaptiveMemorySize The adaptiveMemorySize to set.
	 */
	protected void setAdaptiveMemorySize(final int adaptiveMemorySize) {
		this.adaptiveMemorySize = adaptiveMemorySize;
	}
	
	/**
	 * Get the maximum size of the cache.
	 * @return Returns the maxSize.
	 */
	protected int getMaxSize() {
		return maxSize;
	}
	
	/**
	 * @return Returns the policy in use for managing this cache.
	 */
	protected CacheMaintenancePolicy getPolicy() {
		return policy;
	}
	
	/**
	 * @return Returns the sleepTime.
	 */
	protected long getSleepTime() {
		return sleepTime;
	}
	
	/**
	 * @param maxSize The maxSize to set.
	 */
	protected void setMaxSize(final int maxSize) {
		this.maxSize = maxSize;
	}
	
	/**
	 * @param policy The policy to set.
	 */
	protected void setPolicy(final CacheMaintenancePolicy policy) {
		this.policy = policy;
	}
	
	/**
	 * @param sleepTime The sleepTime to set.
	 */
	protected void setSleepTime(final long sleepTime) {
		this.sleepTime = sleepTime;
	}
	
	/** Get the configuration for this cache.  Mainly used by policies. */
	public Map getConfiguration() {
		return configuration;
	}
	
	/** Shut down this cache. */
	protected void shutdown() {
		log.debug("Shutting down cache: " + getConfiguration().get(Constants.CONFIG_NAME));
		shutdown = true;
		log.info(getEfficiencyReport());
		recordKeeper.reset();
	}
	
}